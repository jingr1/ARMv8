
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'IOTKit_ARMv8MBL_ns' 
 * Target:  'V2M-MPS2' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "IOTKit_ARMv8MBL.h"


#endif /* RTE_COMPONENTS_H */
